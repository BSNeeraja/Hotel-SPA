import React from "react";
import { useLocation } from "react-router-dom";
//import "./hotel_detail.css";

function HotelDetail() {
    const location = useLocation();
    const { hotel } = location.state || {}; // Extract the passed hotel object

    if (!hotel) {
        return <div>Hotel Not Found.</div>; // Display if no hotel data is passed
    }

    return (
        <div className="hotel-detail-container">
            <h1>{hotel.name}</h1>
            <img
                src={hotel.imageUrl}
                alt={hotel.name}
                className="hotel-detail-image"
            />
            <p><strong>Location:</strong> {hotel.location}</p>
            <p><strong>Rating:</strong> {hotel.rating}</p>
            <p><strong>Dates of Travel:</strong> {hotel.datesOfTravel.join(" to ")}</p>
            <p><strong>Board Basis:</strong> {hotel.boardBasis}</p>

            <div>
                <strong>Rooms:</strong>
                <ul>
                    {hotel.rooms.map((room, index) => (
                        <li key={index}>
                            <strong>{room.roomType}</strong>: {room.amount} rooms
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
}

export default HotelDetail;
