import React, { useEffect, useState } from "react";
import { useNavigate } from 'react-router-dom';
import "./hotel_list.css";
function HotelList() {
    const [hotels, setHotels] = useState([]); // State to store the list of hotels
    const [loading, setLoading] = useState(true); // State to handle loading
    const [error, setError] = useState(null); // State to handle errors
    // Fetch hotels from the API
    useEffect(() => {
        const fetchHotels = async () => {
            try {
                const response = await fetch("http://localhost:5000/api/hotels"); // Call the API endpoint
                if (!response.ok) {
                    throw new Error(`Error: ${response.statusText}`); // Handle non-200 responses
                }
                const data = await response.json(); // Parse JSON response
                setHotels(data); // Set the fetched data to state
            } catch (err) {
                setError(err.message); // Set error message in case of failure
            } finally {
                setLoading(false); // Set loading to false once fetching is complete
            }
        };
        fetchHotels();
    }, []); // Empty dependency array ensures this runs only once when the component mounts
    const navigate = useNavigate();
    const handleClick = (id) => {
        navigate(`/hotel/${id}`);
    };
    return (
        <div>
            <h1>Hotels List</h1>
            {loading && <p>Loading...</p>}
            {error && <p style={{ color: "red" }}>Error: {error}</p>}
            {!loading && !error && hotels.length === 0 && <p>No hotels found.</p>}
            {!loading && !error && hotels.length > 0 && (

                <div className="list_container">
                    {hotels.map((hotel) => (
                        <div className="list_element" key={hotel.id} onClick={() => handleClick(hotel.id)}>
                            <h2>{hotel.name}</h2>
                            <p><strong>Location:</strong> {hotel.location}</p>
                            <p><strong>Rating:</strong> {hotel.rating}</p>
                            <img src={hotel.imageUrl} alt={hotel.name} className="hotel-image" />
                            <p><strong>Dates of Travel:</strong> {hotel.datesOfTravel.join(" to ")}</p>
                            <p><strong>Board Basis:</strong> {hotel.boardBasis}</p>

                            <div>
                                <strong>Rooms:</strong>
                                <ul>
                                    {hotel.rooms.map((room, index) => (
                                        <li key={index}>
                                            <strong>{room.roomType}</strong>: {room.amount} rooms
                                        </li>
                                    ))}
                                </ul>
                            </div>
                            {/* Button to navigate to the detail page */}
                            <button onClick={() => handleHotelClick(hotel)} className="detail-button">
                                View Details
                            </button>
                        </div>
                    ))}
                </div>
            )}
        </div>
    )
}
export default HotelList;